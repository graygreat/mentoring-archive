package com.example.product;

import jakarta.persistence.EntityManager;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class ProductJpaRepositoryTest {
    @Autowired
    private SpringDataProductRepository repository;
    @Autowired
    private EntityManager entityManager;

    @Test
    void persistAndReloadAfterClear() {
        ProductEntity saved = repository.saveAndFlush(new ProductEntity("노트", 3000));
        Long id = saved.getId();
        entityManager.clear();
        ProductEntity found = repository.findById(id).orElseThrow();
        assertEquals("노트", found.getName());
        assertNotSame(saved, found);
    }

    @Test
    void derivedQueryAndJpqlHaveSameBoundary() {
        repository.save(new ProductEntity("노트", 3000));
        repository.save(new ProductEntity("무료", 0));
        repository.save(new ProductEntity("펜", 1000));
        entityManager.flush();
        entityManager.clear();
        var derived = repository.findByPriceLessThanEqualOrderByIdAsc(1000);
        var jpql = repository.findAffordable(1000);
        assertEquals(2, derived.size());
        assertEquals(derived.stream().map(ProductEntity::getId).toList(),
                jpql.stream().map(ProductEntity::getId).toList());
    }

    @Test
    void longNamePreservesExistingApiContract() {
        String name = "가".repeat(300);
        Long id = repository.saveAndFlush(new ProductEntity(name, 0)).getId();
        entityManager.clear();
        assertEquals(name, repository.findById(id).orElseThrow().getName());
    }

    @Test
    void managedEntityChangesAreFlushedWithoutSave() {
        ProductEntity saved = repository.saveAndFlush(new ProductEntity("노트", 3000));
        Long id = saved.getId();
        entityManager.clear();
        repository.findById(id).orElseThrow().change("공책", 2000);
        entityManager.flush();
        entityManager.clear();
        assertEquals(2000, repository.findById(id).orElseThrow().getPrice());
    }
}
