package com.example.product;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductCrudTest {
    private final ProductService service =
            new ProductService(new MemoryProductRepository());

    @Test
    void updateKeepsIdAndReplacesValues() {
        Product first = service.create("노트", 3000);
        Product changed = service.update(first.getId(), "  공책  ", 0);
        assertEquals(first.getId(), changed.getId());
        assertEquals("공책", changed.getName());
        assertEquals(0, service.findById(first.getId()).getPrice());
        assertEquals(1, service.findAll().size());
    }

    @Test
    void invalidUpdatePreservesPreviousValues() {
        Product first = service.create("노트", 3000);
        assertThrows(IllegalArgumentException.class,
                () -> service.update(first.getId(), "새 이름", -1));
        assertEquals("노트", service.findById(first.getId()).getName());
        assertEquals(3000, service.findById(first.getId()).getPrice());
    }

    @Test
    void deleteKeepsOtherProductsAndRepeatedDeleteFails() {
        Product first = service.create("노트", 3000);
        Product second = service.create("펜", 1000);
        service.delete(first.getId());
        assertThrows(ProductNotFoundException.class,
                () -> service.findById(first.getId()));
        assertThrows(ProductNotFoundException.class,
                () -> service.delete(first.getId()));
        assertEquals(second.getId(), service.findAll().get(0).getId());
    }

    @Test
    void missingUpdateDoesNotCreateProduct() {
        assertThrows(ProductNotFoundException.class,
                () -> service.update(999, "노트", 3000));
        assertTrue(service.findAll().isEmpty());
    }
}
