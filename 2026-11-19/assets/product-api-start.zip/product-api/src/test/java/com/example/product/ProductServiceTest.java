package com.example.product;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

class ProductServiceTest {
    private final ProductService service =
            new ProductService(new MemoryProductRepository());

    @Test
    void createAndFind() {
        Product saved = service.create("노트", 3000);
        assertEquals("노트", service.findById(saved.getId()).getName());
        assertEquals(1, service.findAll().size());
    }

    @Test
    void rejectInvalidPrice() {
        assertThrows(IllegalArgumentException.class,
                () -> service.create("노트", -1));
        assertTrue(service.findAll().isEmpty());
    }

    @Test
    void rejectMissingProduct() {
        assertThrows(ProductNotFoundException.class,
                () -> service.findById(999));
    }
}
