package com.example.product;

import java.net.URI;
import java.util.List;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/products")
public class ProductController {
    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ProductResponse> create(
            @Valid @RequestBody CreateProductRequest request) {
        Product product = service.create(request.getName(), request.getPrice());
        URI location = URI.create("/products/" + product.getId());
        return ResponseEntity.created(location).body(new ProductResponse(product));
    }

    @GetMapping
    public List<ProductResponse> findAll() {
        return service.findAll().stream().map(ProductResponse::new).toList();
    }

    @GetMapping("/{id}")
    public ProductResponse findById(@PathVariable("id") long id) {
        return new ProductResponse(service.findById(id));
    }

    @PutMapping("/{id}")
    public ProductResponse update(@PathVariable("id") long id,
            @Valid @RequestBody CreateProductRequest request) {
        return new ProductResponse(
                service.update(id, request.getName(), request.getPrice()));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable("id") long id) {
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
