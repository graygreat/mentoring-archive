package com.example.product;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
import org.springframework.stereotype.Repository;

@Repository
public class MemoryProductRepository implements ProductRepository {
    private final Map<Long, Product> store = new ConcurrentHashMap<>();
    private final AtomicLong sequence = new AtomicLong();

    @Override
    public Product save(String name, int price) {
        long id = sequence.incrementAndGet();
        Product product = new Product(id, name, price);
        store.put(id, product);
        return product;
    }

    @Override
    public List<Product> findAll() {
        return store.values().stream()
                .sorted(Comparator.comparingLong(Product::getId))
                .toList();
    }

    @Override
    public Optional<Product> findById(long id) {
        return Optional.ofNullable(store.get(id));
    }

    @Override
    public Optional<Product> update(long id, String name, int price) {
        Product updated = store.computeIfPresent(id,
                (key, previous) -> new Product(key, name, price));
        return Optional.ofNullable(updated);
    }

    @Override
    public boolean delete(long id) {
        return store.remove(id) != null;
    }
}
