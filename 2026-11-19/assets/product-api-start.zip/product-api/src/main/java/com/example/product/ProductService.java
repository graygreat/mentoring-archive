package com.example.product;

import java.util.List;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
    private final ProductRepository repository;

    public ProductService(ProductRepository repository) {
        this.repository = repository;
    }

    public Product create(String name, int price) {
        Product checked = new Product(0, name, price);
        return repository.save(checked.getName(), checked.getPrice());
    }

    public List<Product> findAll() {
        return repository.findAll();
    }

    public Product findById(long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException(id));
    }

    public Product update(long id, String name, int price) {
        Product checked = new Product(id, name, price);
        return repository.update(id, checked.getName(), checked.getPrice())
                .orElseThrow(() -> new ProductNotFoundException(id));
    }

    public void delete(long id) {
        if (!repository.delete(id)) {
            throw new ProductNotFoundException(id);
        }
    }
}
