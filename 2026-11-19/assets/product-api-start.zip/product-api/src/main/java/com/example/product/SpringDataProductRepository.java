package com.example.product;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface SpringDataProductRepository
        extends JpaRepository<ProductEntity, Long> {
    List<ProductEntity> findAllByOrderByIdAsc();
    List<ProductEntity> findByPriceLessThanEqualOrderByIdAsc(int maxPrice);

    @Query("select p from ProductEntity p where p.price <= :maxPrice order by p.id")
    List<ProductEntity> findAffordable(@Param("maxPrice") int maxPrice);
}
