package com.example.product;

public class ProductResponse {
    private final long id;
    private final String name;
    private final int price;

    public ProductResponse(Product product) {
        this.id = product.getId();
        this.name = product.getName();
        this.price = product.getPrice();
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public int getPrice() { return price; }
}
