package com.example.product;

import jakarta.persistence.*;

@Entity
@Table(name = "products")
public class ProductEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Lob
    @Column(nullable = false)
    private String name;
    @Column(nullable = false)
    private int price;

    protected ProductEntity() {
    }

    public ProductEntity(String name, int price) {
        change(name, price);
    }

    public void change(String name, int price) {
        Product checked = new Product(0, name, price);
        this.name = checked.getName();
        this.price = checked.getPrice();
    }

    public Long getId() { return id; }
    public String getName() { return name; }
    public int getPrice() { return price; }

    public Product toProduct() {
        return new Product(id, name, price);
    }
}
