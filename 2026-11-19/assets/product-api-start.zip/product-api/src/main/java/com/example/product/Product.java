package com.example.product;

public class Product {
    private final long id;
    private final String name;
    private final int price;

    public Product(long id, String name, int price) {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("상품명은 필수입니다");
        }
        if (price < 0) {
            throw new IllegalArgumentException("가격은 0 이상이어야 합니다");
        }
        this.id = id;
        this.name = name.strip();
        this.price = price;
    }

    public long getId() { return id; }
    public String getName() { return name; }
    public int getPrice() { return price; }
}
