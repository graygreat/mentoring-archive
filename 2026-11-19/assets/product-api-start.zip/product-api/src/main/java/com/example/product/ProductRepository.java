package com.example.product;

import java.util.List;
import java.util.Optional;

public interface ProductRepository {
    Product save(String name, int price);
    List<Product> findAll();
    Optional<Product> findById(long id);
    Optional<Product> update(long id, String name, int price);
    boolean delete(long id);
}
