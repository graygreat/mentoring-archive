# 19일 복구용 출발 코드 · 16일 완료 상태

새 독립 저장소를 만들지 않습니다. 본인 product-api를 먼저 커밋/백업하세요.
필요한 파일을 비교해 복구하고 선택 검색 등 본인 기능을 보존합니다.
이 ZIP에는 중첩 .git, build, .gradle, DB 파일이 없습니다.

Java 17 / Spring Boot 4.1.2 / Gradle Wrapper 포함.
./gradlew test (Windows: .\gradlew.bat test)
./gradlew bootRun (Windows: .\gradlew.bat bootRun)

현재 API는 MemoryProductRepository를 사용합니다. Entity/Repository 테스트가
통과해도 API가 DB를 쓰는 것은 아닙니다. 19일 작업지에 따라 전환하세요.
./data DB 파일은 공유하지 않습니다. 테스트는 별도 메모리 DB를 사용합니다.
H2는 로컬 수업용입니다. 공개 운영 환경 설정이 아닙니다.
