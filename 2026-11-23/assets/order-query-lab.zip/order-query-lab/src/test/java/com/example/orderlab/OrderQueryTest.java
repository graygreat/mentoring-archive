package com.example.orderlab;

import jakarta.persistence.EntityManager;
import org.hibernate.SessionFactory;
import org.hibernate.stat.Statistics;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest(properties = "spring.jpa.properties.hibernate.generate_statistics=true")
class OrderQueryTest {
    @Autowired
    private OrderQueryRepository repository;
    @Autowired
    private EntityManager entityManager;
    private Statistics statistics;

    @BeforeEach
    void seedAndClear() {
        for (int i = 1; i <= 3; i++) {
            PurchaseOrder order = new PurchaseOrder("주문 " + i);
            order.addItem("노트");
            order.addItem("펜");
            repository.save(order);
        }
        entityManager.flush();
        entityManager.clear();
        statistics = entityManager.getEntityManagerFactory()
                .unwrap(SessionFactory.class).getStatistics();
        statistics.clear();
    }

    @Test
    void lazyCollectionsProduceOnePlusNQueries() {
        var orders = repository.findAllByOrderByIdAsc();
        int totalItems = orders.stream().mapToInt(o -> o.getItems().size()).sum();
        long selects = statistics.getPrepareStatementCount();
        assertEquals(3, orders.size());
        assertEquals(6, totalItems);
        assertEquals(java.util.List.of("주문 1", "주문 2", "주문 3"),
                orders.stream().map(PurchaseOrder::getLabel).toList());
        assertTrue(orders.stream().allMatch(order ->
                order.getItems().stream().map(OrderItem::getName).sorted().toList()
                        .equals(java.util.List.of("노트", "펜"))));
        assertEquals(4, selects);
        System.out.println("lazy-select-count=" + selects);
    }

    @Test
    void fetchJoinLoadsSameResultInOneQuery() {
        var orders = repository.findAllWithItems();
        int totalItems = orders.stream().mapToInt(o -> o.getItems().size()).sum();
        long selects = statistics.getPrepareStatementCount();
        assertEquals(3, orders.size());
        assertEquals(6, totalItems);
        assertEquals(java.util.List.of("주문 1", "주문 2", "주문 3"),
                orders.stream().map(PurchaseOrder::getLabel).toList());
        assertTrue(orders.stream().allMatch(order ->
                order.getItems().stream().map(OrderItem::getName).sorted().toList()
                        .equals(java.util.List.of("노트", "펜"))));
        assertEquals(1, selects);
        System.out.println("fetch-select-count=" + selects);
    }
}
