package com.example.orderlab;

import jakarta.persistence.EntityManager;
import org.hibernate.Hibernate;
import org.hibernate.LazyInitializationException;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
class PersistenceContextTest {
    @Autowired
    private OrderQueryRepository repository;
    @Autowired
    private EntityManager entityManager;
    @Autowired
    private PlatformTransactionManager transactionManager;

    @Test
    void sameContextKeepsIdentityAndFlushWritesChanges() {
        PurchaseOrder saved = repository.saveAndFlush(new PurchaseOrder("처음"));
        Long id = saved.getId();
        entityManager.clear();
        PurchaseOrder first = repository.findById(id).orElseThrow();
        assertSame(first, repository.findById(id).orElseThrow());
        first.rename("변경");
        entityManager.flush();
        entityManager.clear();
        PurchaseOrder reloaded = repository.findById(id).orElseThrow();
        assertNotSame(first, reloaded);
        assertEquals("변경", reloaded.getLabel());
    }

    @Test
    @Transactional(propagation = Propagation.NOT_SUPPORTED)
    void uninitializedCollectionCannotLoadAfterContextCloses() {
        TransactionTemplate tx = new TransactionTemplate(transactionManager);
        Long id = tx.execute(status -> {
            PurchaseOrder order = new PurchaseOrder("분리 실험");
            order.addItem("노트");
            return repository.saveAndFlush(order).getId();
        });
        try {
            PurchaseOrder detached = tx.execute(status ->
                    repository.findById(id).orElseThrow());
            assertFalse(Hibernate.isInitialized(detached.getItems()));
            assertThrows(LazyInitializationException.class,
                    () -> detached.getItems().size());
        } finally {
            tx.executeWithoutResult(status -> repository.deleteById(id));
        }
    }
}
