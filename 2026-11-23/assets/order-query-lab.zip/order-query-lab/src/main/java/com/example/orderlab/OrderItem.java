package com.example.orderlab;

import jakarta.persistence.*;

@Entity
@Table(name = "order_items")
public class OrderItem {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    protected OrderItem() {
    }

    public OrderItem(String name) {
        this.name = name;
    }

    public Long getId() { return id; }
    public String getName() { return name; }
}
