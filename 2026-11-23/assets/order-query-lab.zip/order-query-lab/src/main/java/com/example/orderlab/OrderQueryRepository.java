package com.example.orderlab;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface OrderQueryRepository extends JpaRepository<PurchaseOrder, Long> {
    List<PurchaseOrder> findAllByOrderByIdAsc();

    @Query("select distinct o from PurchaseOrder o left join fetch o.items order by o.id")
    List<PurchaseOrder> findAllWithItems();
}
