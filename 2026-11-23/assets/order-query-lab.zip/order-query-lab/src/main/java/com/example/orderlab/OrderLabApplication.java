package com.example.orderlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderLabApplication {
    public static void main(String[] args) {
        SpringApplication.run(OrderLabApplication.class, args);
    }
}
