package com.example.orderlab;

import java.util.ArrayList;
import java.util.List;
import jakarta.persistence.*;

@Entity
@Table(name = "purchase_orders")
public class PurchaseOrder {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String label;
    @OneToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinColumn(name = "order_id")
    private List<OrderItem> items = new ArrayList<>();

    protected PurchaseOrder() {
    }

    public PurchaseOrder(String label) {
        this.label = label;
    }

    public void addItem(String name) {
        items.add(new OrderItem(name));
    }

    public void rename(String label) { this.label = label; }
    public Long getId() { return id; }
    public String getLabel() { return label; }
    public List<OrderItem> getItems() { return items; }
}
